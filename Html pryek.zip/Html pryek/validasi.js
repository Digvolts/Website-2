function validate(){
    // alert("Test")
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const Gender = document.getElementById("Gender").value;
    const AAAAA = document.getElementById("Location").value;
    const address = document.getElementById("address").value;

    
    const eror1 = document.getElementById("eee1");
    const eror2 = document.getElementById("eee2");
    const eror3 = document.getElementById("eee3");
    const eror4 = document.getElementById("eee4");  
    const eror5 = document.getElementById("eee5");

    var flek = true;

    if(username == ""){
        eror1.innerHTML = "Username must be filled";
        flek = false;

    }else{
        eror1.innerHTML = "";
    }
    if(email == ''){
        eror2.innerHTML = "Email must be filled";
    }
    else if(email.indexOf("@") == -1){
        eror2.innerHTML = "Email must contains '@'";
        flek = false;
    }
    else if(email.split("@").length > 2){
        eror2.innerHTML = "Email must contains only one '@'";
        flek = false;
    }
    else if(!email.endsWith(".com")){
        eror2.innerHTML = "Email must ends with '.com'";
        flek = false;
    }else{
        eror2.innerHTML = "";
    }
    if(Gender == ''){
        eror3.innerHTML = "Gender must be choosen";
        flek = false;
    }else{
        eror3.innerHTML = "";
    }
     if(AAAAA == ''){
        eror4.innerHTML = "Location must be selected";
        flek = false;
    }
    else{
        eror4.innerHTML = "";
    }
     if(address == ''){
        eror5.innerHTML = "Address must be filled";
        flek = false;
    }
    else if(address.length > 101){
        eror5.innerHTML = "Address must be maximum 101 characters";
        flek = false;
    }  
      else{
            eror5.innerHTML = "";
        }
        if(flek){
             if(confirm("Username : "+username+"\nEmail : "+email+"\nGender : "+Gender+"\nLocation : "+AAAAA+"\nAddress : "+address+"\n\n\nAre You Sure???")){
                 alert("Message Has Been Sent");
            }
           
        }
    }